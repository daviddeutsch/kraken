<?php
include(__DIR__ . '/kraken.phar');
